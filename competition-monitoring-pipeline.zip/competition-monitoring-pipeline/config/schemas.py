from datetime import datetime
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, HttpUrl


class CompetitionCandidate(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)
    title: str = Field(min_length=1, max_length=255)
    source_platform: str = Field(min_length=1, max_length=100)
    url: HttpUrl
    deadline: datetime | None = None
    prize_amount: Decimal = Decimal('0.00')
    equity_required: bool = False
    eligibility_criteria: str | None = None
    raw_payload: dict[str, Any] = Field(default_factory=dict)

class ScoredCandidate(CompetitionCandidate):
    relevance_score: float = Field(default=0.0, ge=0.0, le=1.0)
    suitability_summary: str | None = None

class NotificationItem(BaseModel):
    title: str
    url: str
    source_platform: str
    relevance_score: float
    suitability_summary: str | None = None
    deadline: datetime | None = None
    prize_amount: Decimal = Decimal('0.00')
