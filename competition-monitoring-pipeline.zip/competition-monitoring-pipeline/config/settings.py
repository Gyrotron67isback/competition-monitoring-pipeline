import json
from functools import lru_cache

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='ignore')
    database_url: str = 'postgresql+psycopg://competition:competition@localhost:5432/competition_monitor'
    source_urls: list[str] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=lambda: ['founder', 'prototype', 'small business', 'early stage', 'non-dilutive'])
    min_keyword_score: float = 0.20
    min_llm_score: float = 0.65
    request_timeout_seconds: float = 30.0
    user_agent: str = 'CompetitionMonitor/0.1 (+contact@example.com)'
    slack_webhook_url: str | None = None
    discord_webhook_url: str | None = None
    smtp_host: str | None = None
    smtp_port: int = 587
    smtp_username: str | None = None
    smtp_password: str | None = None
    email_from: str | None = None
    email_to: list[str] = Field(default_factory=list)
    llm_provider: str = 'none'
    openai_api_key: str | None = None
    openai_model: str = 'gpt-4o-mini'

    @field_validator('source_urls', 'keywords', 'email_to', mode='before')
    @classmethod
    def parse_json_lists(cls, value):
        if isinstance(value, str):
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return [item.strip() for item in value.split(',') if item.strip()]
        return value

@lru_cache
def get_settings() -> Settings:
    return Settings()
