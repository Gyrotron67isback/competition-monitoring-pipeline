import smtplib
from email.message import EmailMessage

import httpx

from config.schemas import NotificationItem
from config.settings import Settings


def render_markdown(items: list[NotificationItem]) -> str:
    lines = ['## New competition opportunities', '']
    for item in items:
        deadline = item.deadline.isoformat() if item.deadline else 'Not listed'
        lines += [f'### [{item.title}]({item.url})', f'- Source: {item.source_platform}', f'- Relevance: {item.relevance_score:.0%}', f'- Prize: ${item.prize_amount:,.2f}', f'- Deadline: {deadline}', f'- Summary: {item.suitability_summary or ""}', '']
    return '\n'.join(lines)

class Notifier:
    def __init__(self, settings: Settings): self.settings = settings
    def send(self, items: list[NotificationItem]) -> None:
        if not items: return
        markdown = render_markdown(items)
        if self.settings.slack_webhook_url:
            httpx.post(self.settings.slack_webhook_url, json={'text': markdown}, timeout=15).raise_for_status()
        if self.settings.discord_webhook_url:
            httpx.post(self.settings.discord_webhook_url, json={'content': markdown}, timeout=15).raise_for_status()
        if self.settings.smtp_host and self.settings.email_from and self.settings.email_to:
            message = EmailMessage(); message['Subject'] = f'{len(items)} new competition opportunities'; message['From'] = self.settings.email_from; message['To'] = ', '.join(self.settings.email_to); message.set_content(markdown)
            with smtplib.SMTP(self.settings.smtp_host, self.settings.smtp_port) as smtp:
                smtp.starttls();
                if self.settings.smtp_username: smtp.login(self.settings.smtp_username, self.settings.smtp_password or '')
                smtp.send_message(message)
