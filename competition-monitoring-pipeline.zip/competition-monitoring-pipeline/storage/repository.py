import hashlib
from collections.abc import Iterable

from sqlalchemy import create_engine, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import sessionmaker
from tenacity import retry, stop_after_attempt, wait_exponential

from config.schemas import ScoredCandidate
from config.settings import Settings
from storage.models import Base, Competition


class CompetitionRepository:
    def __init__(self, settings: Settings):
        self.engine = create_engine(settings.database_url, pool_pre_ping=True)
        self.sessions = sessionmaker(self.engine, expire_on_commit=False)

    def init_db(self) -> None:
        Base.metadata.create_all(self.engine)

    @staticmethod
    def url_hash(url: str) -> str:
        return hashlib.sha256(url.encode('utf-8')).hexdigest()

    def exists(self, url: str) -> bool:
        with self.sessions() as session:
            return session.scalar(select(Competition.id).where(Competition.url_hash == self.url_hash(url))) is not None

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=0.5, max=5), reraise=True)
    def insert_many(self, candidates: Iterable[ScoredCandidate]) -> list[Competition]:
        inserted = []
        with self.sessions() as session:
            for candidate in candidates:
                url = str(candidate.url)
                if session.scalar(select(Competition.id).where(Competition.url_hash == self.url_hash(url))):
                    continue
                row = Competition(url_hash=self.url_hash(url), title=candidate.title, source_platform=candidate.source_platform,
                    url=url, deadline=candidate.deadline, prize_amount=candidate.prize_amount,
                    equity_required=candidate.equity_required, eligibility_criteria=candidate.eligibility_criteria,
                    relevance_score=candidate.relevance_score, suitability_summary=candidate.suitability_summary,
                    raw_payload=candidate.raw_payload, status='qualified')
                session.add(row)
                inserted.append(row)
            try:
                session.commit()
            except IntegrityError:
                session.rollback()
                raise
        return inserted
