from typing import Protocol

from config.schemas import CompetitionCandidate, ScoredCandidate


class RelevanceModel(Protocol):
    def score(self, candidate: CompetitionCandidate) -> tuple[float, str]: ...

def keyword_score(candidate: CompetitionCandidate, keywords: list[str]) -> float:
    haystack = ' '.join([candidate.title, candidate.eligibility_criteria or '']).lower()
    if not keywords: return 1.0
    hits = sum(1 for keyword in keywords if keyword.lower() in haystack)
    return min(1.0, hits / len(keywords))

def prefilter(candidates: list[CompetitionCandidate], keywords: list[str], minimum: float) -> list[CompetitionCandidate]:
    return [candidate for candidate in candidates if keyword_score(candidate, keywords) >= minimum]

def classify(candidates: list[CompetitionCandidate], model: RelevanceModel | None, minimum: float) -> list[ScoredCandidate]:
    results = []
    for candidate in candidates:
        score, summary = model.score(candidate) if model else (0.75, 'Passed deterministic relevance filter; LLM classification disabled.')
        if score >= minimum:
            results.append(ScoredCandidate(**candidate.model_dump(), relevance_score=score, suitability_summary=summary))
    return results

class OpenAIRelevanceModel:
    def __init__(self, api_key: str, model: str):
        from openai import OpenAI
        self.client, self.model = OpenAI(api_key=api_key), model

    def score(self, candidate: CompetitionCandidate) -> tuple[float, str]:
        prompt = ('Score this competition for a founder seeking non-dilutive opportunities. Return JSON with score 0..1 and summary. '
                  f'Title: {candidate.title}\nEligibility: {(candidate.eligibility_criteria or "")[:1800]}')
        response = self.client.chat.completions.create(model=self.model, temperature=0, response_format={'type': 'json_object'},
            messages=[{'role': 'system', 'content': 'You are a concise relevance classifier.'}, {'role': 'user', 'content': prompt}])
        import json
        data = json.loads(response.choices[0].message.content or '{}')
        return float(data.get('score', 0)), str(data.get('summary', ''))[:4000]
