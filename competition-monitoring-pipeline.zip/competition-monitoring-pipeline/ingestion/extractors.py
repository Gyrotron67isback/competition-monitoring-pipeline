import re
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from dateutil import parser as date_parser

from config.schemas import CompetitionCandidate

MONEY_RE = re.compile(r'(?i)(?:\$|USD\s*)([\d,]+(?:\.\d{1,2})?)')
DATE_RE = re.compile(r'(?i)(?:deadline|due|close[sd]?|ends?)\D{0,20}([A-Z][a-z]+\s+\d{1,2},?\s+\d{4}|\d{4}-\d{2}-\d{2})')

def _candidate(title: str, url: str, source: str, text: str, raw: dict) -> CompetitionCandidate | None:
    if not title or not url.startswith(('http://', 'https://')):
        return None
    money = MONEY_RE.search(text)
    deadline = None
    date_match = DATE_RE.search(text)
    if date_match:
        try: deadline = date_parser.parse(date_match.group(1), fuzzy=True)
        except (ValueError, OverflowError): pass
    try:
        return CompetitionCandidate(title=title[:255], source_platform=source[:100], url=url, deadline=deadline,
            prize_amount=money and money.group(1).replace(',', '') or '0', equity_required=bool(re.search(r'(?i)equity|dilution', text)),
            eligibility_criteria=text[:2000], raw_payload=raw)
    except Exception:  # noqa: BLE001
        return None

def extract_html(html: str, base_url: str, source: str) -> list[CompetitionCandidate]:
    soup = BeautifulSoup(html, 'html.parser')
    for tag in soup(['script', 'style', 'noscript']): tag.decompose()
    results, seen = [], set()
    for link in soup.select('a[href]'):
        href = urljoin(base_url, link.get('href', ''))
        title = ' '.join(link.get_text(' ', strip=True).split())
        container = link.find_parent(['article', 'li', 'div', 'section']) or link
        text = ' '.join(container.get_text(' ', strip=True).split())[:5000]
        if len(title) < 5 or href in seen: continue
        candidate = _candidate(title, href, source, text, {'title': title, 'text': text})
        if candidate: results.append(candidate); seen.add(href)
    return results

def extract_feed(xml: str, base_url: str, source: str) -> list[CompetitionCandidate]:
    soup = BeautifulSoup(xml, 'xml')
    results = []
    for item in soup.find_all(['item', 'entry']):
        title = item.find('title')
        link = item.find('link')
        href = (link.get('href') if link and link.get('href') else link.get_text(strip=True) if link else '')
        text = ' '.join(item.get_text(' ', strip=True).split())
        candidate = _candidate(title.get_text(' ', strip=True) if title else '', urljoin(base_url, href), source, text, {'xml': text})
        if candidate: results.append(candidate)
    return results
