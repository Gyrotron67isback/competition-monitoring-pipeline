import httpx
from tenacity import retry, stop_after_attempt, wait_random_exponential

from config.settings import Settings


class FetchError(RuntimeError):
    pass

class HttpFetcher:
    def __init__(self, settings: Settings):
        self.settings = settings

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, max=12), reraise=True)
    def fetch(self, url: str) -> str:
        try:
            response = httpx.get(url, headers={'User-Agent': self.settings.user_agent}, timeout=self.settings.request_timeout_seconds, follow_redirects=True)
            response.raise_for_status()
            return response.text
        except httpx.HTTPError as exc:
            raise FetchError(f'Failed to fetch {url}: {exc}') from exc

class BrowserFetcher:
    def __init__(self, settings: Settings):
        self.settings = settings

    def fetch(self, url: str) -> str:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise FetchError('Install the browser extra and run playwright install chromium') from exc
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=True)
            context = browser.new_context(user_agent=self.settings.user_agent, extra_http_headers={'Accept-Language': 'en-US,en;q=0.9'})
            page = context.new_page()
            try:
                page.goto(url, wait_until='domcontentloaded', timeout=int(self.settings.request_timeout_seconds * 1000))
                page.wait_for_load_state('networkidle', timeout=int(self.settings.request_timeout_seconds * 1000))
            except Exception:  # noqa: BLE001
                page.wait_for_timeout(1000)
            html = page.content()
            browser.close()
            return html
