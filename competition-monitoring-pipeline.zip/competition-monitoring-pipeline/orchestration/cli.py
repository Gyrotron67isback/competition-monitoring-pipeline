import logging

logger = logging.getLogger(__name__)
from urllib.parse import urlparse

import typer

from config.schemas import NotificationItem
from config.settings import get_settings
from filtering.scoring import OpenAIRelevanceModel, classify, prefilter
from ingestion.extractors import extract_feed, extract_html
from ingestion.fetchers import BrowserFetcher, HttpFetcher
from notifications.dispatch import Notifier
from storage.repository import CompetitionRepository

app = typer.Typer(help='Competition monitoring pipeline')
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

@app.command('init-db')
def init_db():
    repo = CompetitionRepository(get_settings()); repo.init_db(); typer.echo('Database initialized.')

@app.command('run')
def run(dry_run: bool = typer.Option(False, help='Do not write to DB or send notifications'), browser: bool = typer.Option(False, help='Use Playwright for JavaScript-rendered pages')):
    settings = get_settings()
    if not settings.source_urls:
        raise typer.BadParameter('SOURCE_URLS must contain at least one URL')
    repo = CompetitionRepository(settings)
    if not dry_run: repo.init_db()
    fetcher = BrowserFetcher(settings) if browser else HttpFetcher(settings)
    candidates = []
    for source_url in settings.source_urls:
        try:
            content = fetcher.fetch(source_url)
            source = urlparse(source_url).netloc or source_url
            if '<rss' in content[:1000].lower() or '<feed' in content[:1000].lower() or '<channel' in content[:1000].lower():
                candidates.extend(extract_feed(content, source_url, source))
            else:
                candidates.extend(extract_html(content, source_url, source))
        except Exception as exc:  # noqa: BLE001
            logger.warning('Quarantined source %s: %s', source_url, exc)
    candidates = prefilter(candidates, settings.keywords, settings.min_keyword_score)
    model = None
    if settings.llm_provider.lower() == 'openai' and settings.openai_api_key:
        model = OpenAIRelevanceModel(settings.openai_api_key, settings.openai_model)
    qualified = classify(candidates, model, settings.min_llm_score)
    if dry_run:
        for item in qualified: typer.echo(f'{item.title} | {item.relevance_score:.2f} | {item.url}')
        typer.echo(f'Found {len(qualified)} qualified candidates (dry run).')
        return
    inserted = repo.insert_many(qualified)
    notifications = [NotificationItem(title=row.title, url=row.url, source_platform=row.source_platform,
        relevance_score=row.relevance_score, suitability_summary=row.suitability_summary,
        deadline=row.deadline, prize_amount=row.prize_amount) for row in inserted]
    Notifier(settings).send(notifications)
    typer.echo(f'Inserted {len(inserted)} new competitions.')

if __name__ == '__main__': app()
