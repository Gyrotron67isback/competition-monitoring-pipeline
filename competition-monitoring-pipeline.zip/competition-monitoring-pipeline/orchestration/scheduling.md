# Scheduling

## Cron

Run every six hours:

```cron
0 */6 * * * cd /opt/competition-monitoring-pipeline && .venv/bin/competition-monitor run >> /var/log/competition-monitor.log 2>&1
```

## Prefect

Wrap `orchestration.cli.run` in a Prefect deployment if the team already operates Prefect. Keep the CLI as the canonical entry point so local, cron, and Prefect executions share the same behavior.

## Failure policy

The fetcher retries transient HTTP failures three times with exponential backoff. Source-level failures are quarantined and logged so one bad source does not stop the remaining sources. Database writes retry three times. Notification delivery currently fails the run when a configured destination rejects a request; put the scheduler behind a retrying process supervisor for production.
