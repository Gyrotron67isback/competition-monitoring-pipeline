from config.schemas import CompetitionCandidate, NotificationItem
from filtering.scoring import keyword_score, prefilter
from ingestion.extractors import extract_feed, extract_html
from notifications.dispatch import render_markdown


def test_keyword_scoring_and_prefilter():
    candidate = CompetitionCandidate(title='Founder prototype grant', source_platform='example', url='https://example.org/a', eligibility_criteria='For early stage small business')
    assert keyword_score(candidate, ['founder', 'prototype']) == 1.0
    assert len(prefilter([candidate], ['founder'], 0.5)) == 1

def test_html_extractor_normalizes_candidate():
    html = '<article><a href="/grant">Prototype Grant</a><p>Deadline December 1, 2026. Prize $10,000.</p></article>'
    items = extract_html(html, 'https://example.org/opportunities', 'example.org')
    assert items[0].title == 'Prototype Grant'
    assert str(items[0].url) == 'https://example.org/grant'
    assert float(items[0].prize_amount) == 10000.0

def test_feed_extractor():
    xml = '<rss><channel><item><title>Small Business Award</title><link>https://example.org/a</link><description>Non-dilutive prize</description></item></channel></rss>'
    assert extract_feed(xml, 'https://example.org/feed.xml', 'example.org')[0].title == 'Small Business Award'

def test_markdown_notification():
    item = NotificationItem(title='Award', url='https://example.org/a', source_platform='example', relevance_score=0.8)
    assert '[Award](https://example.org/a)' in render_markdown([item])
