CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS competitions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    url_hash VARCHAR(64) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    source_platform VARCHAR(100) NOT NULL,
    url TEXT NOT NULL,
    deadline TIMESTAMP WITH TIME ZONE NULL,
    prize_amount NUMERIC(12, 2) DEFAULT 0.00,
    equity_required BOOLEAN DEFAULT FALSE,
    eligibility_criteria TEXT,
    relevance_score FLOAT DEFAULT 0.0,
    suitability_summary TEXT,
    raw_payload JSONB DEFAULT '{}'::jsonb,
    status VARCHAR(50) DEFAULT 'unprocessed',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_competitions_url_hash ON competitions(url_hash);
CREATE INDEX IF NOT EXISTS idx_competitions_relevance ON competitions(relevance_score DESC);
